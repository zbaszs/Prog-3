<?php

echo 'hola mundo'

?>