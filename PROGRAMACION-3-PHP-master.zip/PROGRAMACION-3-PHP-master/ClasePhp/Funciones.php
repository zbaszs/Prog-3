<?php
function Saludar($nombre)
{
    echo $nombre;
}

?>