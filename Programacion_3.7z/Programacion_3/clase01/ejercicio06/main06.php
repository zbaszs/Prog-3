<?php
    include "funciones06.php";
    Operar("+",6,7);
    Operar("*",7,4);
    Operar("/",8,4);
    Operar("-",6,7);
?>