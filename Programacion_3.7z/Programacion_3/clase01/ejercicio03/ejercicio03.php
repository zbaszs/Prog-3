<?php
    $x=-3;
    $y=15;
    echo "X=".$x."<br>Y=".$y."<br>Suma=".($x+$y);
?>