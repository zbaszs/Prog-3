<?php
//MUESTRA LA INFO CONTENIDA EN $_GET
echo "GET<br/>";
var_dump($_GET);
echo "<br/>";

//MUESTRA LA INFO CONTENIDA EN $_POST
echo "POST<br/>";
var_dump($_POST);
echo "<br/>";

//MUESTRA LA INFO CONTENIDA EN $_REQUEST
echo "REQUEST<br/>";
var_dump($_REQUEST);