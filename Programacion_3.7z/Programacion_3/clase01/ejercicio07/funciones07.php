<?php
    function MostrarFecha($fecha)
    {
        echo ($fecha);
    }
?>