<?php
    function InvertirPalabra($palabra)
    {
        echo "Palabra: " . $palabra ."<br>";
        echo "Palabra invertida: " .strrev($palabra)."<br>";
    }
?>