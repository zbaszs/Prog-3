<?php
    include "funciones16.php";
    InvertirPalabra("Hola");
    InvertirPalabra("Caca");
    InvertirPalabra("eeeeeeeeeeeeeeeE");
?>