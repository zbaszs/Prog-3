<?php
    $lapicera["color"]="rojo";$lapicera["marca"]="BIC";$lapicera["trazo"]="Grueso";$lapicera["precio"]=18;
    var_dump($lapicera);
?>