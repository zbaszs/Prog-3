<?php
    include "funciones07.php";
    MostrarFecha(date("F"));
    MostrarFecha(date(" m"));
?>