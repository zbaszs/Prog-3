<?php
    $x=-3;
    $y=15;
    echo "La suma de ".$x ." y ".$y." es: ".($x+$y);
?>