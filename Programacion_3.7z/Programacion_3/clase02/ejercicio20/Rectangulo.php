<?php
    include "Punto.php";
    class Rectangulo
    {
        private $_vertice1;
        private $_vertice2;
        private $_vertice3;
        private $_vertice4;
        public $area;
        public $ladoUno;
        public $ladoDos;
        public $perimetro;

        public function __construct($v1,$v3)
        {
            
        }
    }
?>