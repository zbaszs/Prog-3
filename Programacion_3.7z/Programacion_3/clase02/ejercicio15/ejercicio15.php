<?php
    include "funciones15.php";
    Potencias();
?>