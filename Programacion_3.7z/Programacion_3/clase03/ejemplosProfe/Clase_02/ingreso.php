<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="escribir.php" method="post">
    Nombre:<input type="text" name="nombre"><br>
    Apellido:<input type="text" name="apellido">
    <br>
    <input type="submit" value="Enviar" name="btnEnviar">
    <input type="submit" value="Limpiar" name="btnEnviar">
    
    </form>
</body>
</html>

<?php


?>