<?php

$resultado = 0;
$contador = 0;
while($resultado <1000)
{
    $resultado = $resultado + 1;
    $contador ++;
}
echo 'El resultado es :' . $resultado;
echo 'Se Sumaron :' . $contador . 'Numeros';

?>