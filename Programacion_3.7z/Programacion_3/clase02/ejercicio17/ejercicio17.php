<?php
    include "funciones17.php";
    if(Validar("Programacion",13))
    {
        echo "Programacion palabra valida<br>";
    }
    else
    {
        echo "Programacion palabra invalida<br>";
    }
    if(Validar("HOLA",4))
    {
        echo "Hola palabra valida<br>";
    }
    else
    {
        echo "Hola palabra invalida<br>";
    }
?>