<?php
    include "funciones05.php";
    ValorEnMedio(1,2,3);
    ValorEnMedio(4,3,7);
    ValorEnMedio(7,5,7);
    ValorEnMedio(3,8,5);
?>