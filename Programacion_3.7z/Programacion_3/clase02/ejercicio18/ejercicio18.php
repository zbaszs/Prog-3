<?php
    include "funciones18.php";
    if(EsPar(4))
    {
        echo "El numero 4 es par<br>";
    }
    else
    {
        echo "El numero 4 es impar<br>";
    }

    if(EsPar(7))
    {
        echo "El numero 7 es par<br>"; 
    }
    else
    {
        echo "El numero 7 es impar<br>"; 
    }

    if(EsImpar(3))
    {
        echo "El numero 3 es impar<br>"; 
    }
    else
    {
        echo "El numero 3 es par<br>"; 
    }
?>