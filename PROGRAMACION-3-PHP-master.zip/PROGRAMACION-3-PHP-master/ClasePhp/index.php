<?php

include_once "Funciones.php";
require_once "clases/alumno.php";
$instancia = new persona("hernann",41352901);

$instancia->Saludar();

$alumno = new alumno(1,2,"hernan",41352901);
$alumno->saludar();

?>