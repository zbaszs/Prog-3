<?php
    $nombre="Lautaro";
    $apellido="Medeiros";
    echo $nombre.",".$apellido;
?>